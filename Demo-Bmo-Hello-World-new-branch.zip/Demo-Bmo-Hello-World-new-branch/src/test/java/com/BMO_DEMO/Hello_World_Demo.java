package com.BMO_DEMO;

public class Hello_World_Demo {
	

	public static void main(String[] args)
	{
	System.out.println("DISPLAY HELLO WORLD");
	}

}
